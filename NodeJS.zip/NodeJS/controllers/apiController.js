module.exports = function(app){ //Controllers are actually modules and this exports function will make sure that every change to the app
                                    // Will be changed everywhere
    app.get('/api/person/:id', function(req, res){
        //Get the data from the DB
        res.json({ firstname: 'Roien', lastname: 'Eshaghzey' })
    });
    
    app.post('/api/person', function(req, res){
        // Save to the DB
    });
    
    app.delete('/api/person/:id', function(req, res){
        // Delete from the DB !!!!NO HARD DELETE ALLOWED, ONLY SOFT DELETE WITH 'DELETED-AT'!!!!
    });
}