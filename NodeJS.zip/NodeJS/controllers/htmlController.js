var bodyParser = require('body-parser');

var urlencodedParser = bodyParser.urlencoded({ extended: false });
var jsonParser = bodyParser.json();

module.exports = function(app){
    
    app.get('/', function(req, res){ //Can also be app.post if the browseraction sends a post request and it will invoke another function 
        res.render('index'); //Extension is get by the line app.set('view engine', 'ejs' (This will determine which extension to look for))
    });
    //Making a new route, :id says to express that it could be anything
    app.get('/person/:id', function(req, res){ // :id is the variable name 
        res.render('person', { ID: req.params.id, Qstr: req.query.qstr });
    });
    
    app.post('/person', urlencodedParser, function(req, res){ //Callback function will run before the function 
        res.send('Thank you');
        console.log(req.body.firstname);
        console.log(req.body.lastname);
    });
}