var express = require('express');
var app = express(); // This is also a function, but with properties and methods on it (see sourcecode express)
var mssql = require("mssql");

var apiController = require('./controllers/apiController');
var htmlController = require('./controllers/htmlController')

var port = process.env.PORT || 3000; // It will take the variables of the environment (in this case) for the PORT or (||) if there is none,
                                                            // It will take the default value (3000);

// If u leave out the route in .use, it will invoke for EVERY route, good for logging
app.use('/assets', express.static(__dirname + '/public')); //Node will handle this when the response will contain for example href=assets/...
                                                            // and will get whatever is after the assets/ (as seen below) in this folder (public)

app.set('view engine', 'ejs'); //By default ejs will look for the files in a folder named 'Views'


app.use('/', function(req, res){ // Custom middleware that whenever a route hits this ('/'), the function will be executed
    
    console.log('Request url: ' + req.url);

    var dbconfig = {
        user: "devtest",
        password: "roien1995",
        server: "localhost",
        database: "NodeDBTest",
    };
    
    new mssql.ConnectionPool(dbconfig, function (err) {
        
        if (err) console.log(err);
        
        // create Request object
        var request = new mssql.Request(dbconfig);
        
        // query to the database and get the data
        request.query('select * from Members', function (err, recordset) {
        
        if (err) console.log(err)
        
        // send data as a response
        res.send(recordset);
        
        });
        });
    
    // try{
    //     const pool = new mssql.ConnectionPool(dbconfig, err => {
    //     pool.connect(dbconfig);
    //         // Query
         
    //         pool.request() // or: new sql.Request(pool1)
    //         .query('SELECT Name FROM [Sports]', (err, result) => {
    //             // ... error checks
         
    //             console.dir(result);
    //             console.log(result);
    //         })
         
    //     })

    //     pool.on('error', err => {
    //         console.log(err);
    //     })
    // }
    // catch(err){
    //     console.log('something went wrong');
    // }
    
     
    
    

    // (async function(){
    //     try{
    //         console.log('Connecting...');
    //         let pool = await new mssql.ConnectionPool(dbconfig);
            
    //         pool.connect(dbconfig);
    //         try{
    //             let result = await pool.request().query("SELECT * FROM Sports;");
    //             console.log(result);
    //         }
    //         catch(error){
    //             console.log('Loopt fout bij query');
    //         }

    //     } catch (err){
    //         console.log('Loopt fout bij connection');
    //     }
    //     }
    // )()

     // var pool = new mssql.ConnectionPool({
    //      user: 'Roien-klas',
    //      password: 'roien1995',
    //      server: 'localhost',
    //      database: 'NodeDBTest',
    //      pool:{
    //          acquireTimeoutMillis: 15000
    //      }
    // });

    // pool.connect( error => {
    //      console.log('De connectie met de DB loopt mis.')
    // });
    
    // var request = new mssql.Request();


    // pool.query('SELECT * FROM Members;',
    //     function(err, recordset){
    //         if(err){
    //             console.log('The query could not be executed. Check connection to DB and Back code.');
    //         }
            
    //         console.log(recordset);
    //     });

});



apiController(app);
htmlController(app);

app.listen(port); //This doesn't have to a specific ports it has to listen to